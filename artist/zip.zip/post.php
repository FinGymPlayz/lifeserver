<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prank</title>
    <link rel="stylesheet" href="hacked.css">
</head>
<body>
<audio id="musicplayer">
  <source src="hacking.mp3" type="audio/mp3" />
</audio>
<button onclick="document.getElementById('musicplayer').play()">Play Music</button>

    <div class="matrix" id="matrix">YOU HAVE BEEN HACKED<br>Your IP:
    <br><br>
    <p id="ip"></p>
    </div>
    <script src="script.js"></script>
</body>
</html>
